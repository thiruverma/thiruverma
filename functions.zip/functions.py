'''def Sqr (Number):                                                                                                                           
    Number *= Number
    return Number  
var=5
print(var)
FiveSquare = Sqr(var)
SqrSqrfive = Sqr(FiveSquare)
print(FiveSquare)
print(SqrSqrfive)'''

'''def love (misscount):
    misscount *=3000
    print("I miss you", misscount,"times")
    return misscount
Count= love(3.9)'''


def Genre (Var):
    Var = Var
    print("Genre is",Var)
    return Var   

def Artist(Var):
    Var = Var
    print("Artist is",Var)
    return Var

def Year(Var):
    Var=Var
    print("Realsed on", Var)
    return Var   

count= Genre("Rock"),Artist("21pilots"),Year("13-11-2021")