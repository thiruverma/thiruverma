

def Temp(Temperatur,Thermo,heat):
    if Temperatur == Thermo or Temperatur == heat:   
        print("True")

    elif heat == Thermo:
      print("True")

    else:
        print("False")

Temp(15,16,20)       
