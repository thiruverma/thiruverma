Artist = "21pilots"
Genre = "Metal"
DurationInSeconds = "3.28secs"
Leadguitarist = "Mohan"
#added new variable Lead guitarist and got to know single line comment 
'''and 
also
multiple line comments'''
print(Artist)
print(Genre)
print(DurationInSeconds)
print(Leadguitarist)